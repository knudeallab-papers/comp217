package dataClass;

import javax.swing.JFrame;

public class main_Library extends JFrame{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
